<?php session_start();?>

<!DOCTYPE html>
<html>
    <head>
        <title>Zure erreserbak</title>
        <meta charset=UTF-8>
        <!-- <div style="background-image: url('/img/fondo.jfif');"> -->
        <link rel="stylesheet" type="text/css" href="../CSS/IkusiErreserbak.css" media="screen" />
        
        
    </head>
    <body>
        <h1> ZURE ERRESERBAK </h1>

        <!--ERRESERBEN TAULA-->
    
    <center><table width=100% border="3" cellspacing=1 cellpadding=3 style="font-size: 12pt"><tr>
    <td><font face="verdana"><b>NAN</b></font></td>
    <td><font face="verdana"><b>IZENA</b></font></td>
    <td><font face="verdana"><b>MAHAIA</b></font></td>
    <td><font face="verdana"><b>EGUNA</b></font></td>
    <td><font face="verdana"><b>ORDUA</b></font></td>
    <!-- <td><font face="verdana"><b>IZENA</b></font></td> -->
    </tr>


<?php
$nan = $_SESSION['nan'];


$erreserbak = simplexml_load_file("../xml/Erreserbak.xml");
$erabiltzaileak = simplexml_load_file("../xml/Erabiltzaileak.xml");

    foreach ($erreserbak as $erreserba){
        //XMLtik irakurri datuak
        $nanxml = $erreserba->nan;
        $mahaia = $erreserba->mahaia;
        $data = $erreserba->data;
        $time = $erreserba->time;
        if($nan == $nanxml ){

            foreach ($erabiltzaileak as $erabiltzaile){
                $nanerabiltzaile = $erabiltzaile->nan;

                if($nanerabiltzaile == $nan){
                    $izena=$erabiltzaile->izena;
                }
    
            }
            //zutabeetan ondo adierazteko
            echo "<tr>";
            echo "<td>".$nanxml."</td>";
            echo "<td>".$izena."</td>";
            echo "<td>".$mahaia."</td>";
            echo "<td>".$data."</td>";
            echo "<td>".$time."</td>";
            echo "</tr>";
            
        }
        
        
    }
?>

</table>
<form>
    <center><a type="submit" class="botoia" href="../html/Login.html">ATZERA</a></center>
</form>
</center>
</body>
</html>