<?php

$server = "localhost";
$username = "id18240714_admin";
$password =  "NLd)$#3+M=]TD7>*";
$database = "id18240714_iritziak";

/*Konexioa ireki*/
$con=mysqli_connect($server,$username,$password,$database);

/*konexioa egiaztatu*/ 
if(!$con){
    die("<script>alert('Konexio Errorea'.)</script>");
}


?>