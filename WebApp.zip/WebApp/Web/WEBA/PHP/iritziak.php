
<!DOCTYPE html>
<html>
    <head>
        <title>Iritziak</title>
        <meta charset=UTF-8>
        <!-- <div style="background-image: url('/img/fondo.jfif');"> -->
        <link rel="stylesheet" type="text/css" href="../CSS/iritziak.css" media="screen" />
        
        <script type="text/javascript" src="../js/balidatu.js"> </script>
        
    </head>
    <body>
        <h1> Zuen Iritziak </h1>

            <nav class="nav">
            <!-- menua ankla eginez -->
                <ul class="menu">
                <li><a href="../index.html">Inicio</a></li>
                <li><a href="../html/Ordutegia.html">Ordutegia</a></li>
                <li><a href="../PHP/iritziak.php">Iritziak</a></li>
                <li><a href="../html/Argazkiak.html">Argazkiak</a></li>
                <li><a href="../html/Erreserbak.html">Erreserbak</a></li>
                <li><a href="../html/Login.html">Log in</a></li>
                </ul> 
            </nav>

            <!-- Iritziak  -->


        <div class="container">
            <form action="../PHP/iritziak.php" method="POST"  class="form" onsubmit="return EmailBalidazioa()">
                <div class="erdia">
                    <div class="karratu">
                        <label for="izena">Izena</label>
                        <input type="text" name="name" id="name" placeholder="Izena idatzi mesedez"required>
                    </div>
                    <div class="karratu">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="Email-a idatzi mesedez" required>
                    </div>
                </div>
                <div class="karratu textarea">
                    <label for="iruzkin">Iruzkin</label>
                    <textarea  name="iruzkin" id="iruzkin" placeholder="Iruzkina idatzi mesedez" required></textarea>
                </div>
                <div class="karratu">
                    <button name="igo"class="botoia">Bidali Iruzkina</button>   
                </div>
                
            </form>  
            <!-- datu-baseko datuak lortu eta komentario moduan formularioan jarri, iruzkin guztiak ikusteko -->
            <div class="koment">
                <?php 
                include 'GordeIritziak.php';
			    $sql = "SELECT * FROM iritzi_taula";
			    $result = mysqli_query($con, $sql);
			    if (mysqli_num_rows($result) > 0) {
				    while ($row = mysqli_fetch_assoc($result)) {

			    ?>
                <div class="item">
                    <h3><?php echo $row['izena']; ?></h3>
                    <a href="mailto:<?php echo $row['korreoa']; ?>"><?php echo $row['korreoa']; ?></a>
                    <p><?php echo $row['iruzkina']; ?></p>
                </div>
                <?php
                    }
                }
                ?>
            </div> 
        </div>
         
        <!-- menuaren javascripta -->
        <script src="../js/menu.js "></script>
    </body>

</html>
 <!--GordeIritziak gehitu  -->
<?php

error_reporting(0);//Errorerik ez erakusteko
include 'GordeIritziak.php';

if(isset($_POST['name'])){ 
    $name = $_POST['name']; //Izena lortu formulariotik
    $email = $_POST['email'];//Emaila lortu formulariotik
    $iruzkin = $_POST['iruzkin'];//Iruzkina lortu formulariotik

    //Datuak datu-basean gorde
    $sql = "INSERT INTO iritzi_taula (izena,korreoa,iruzkina)
            VALUES ('$name','$email','$iruzkin')";
    $result = mysqli_query($con,$sql);
    //gorde direla egiaztapena
    if($result){
        echo "<script>alert('Iruzkina ondo gorde da.')
        window.location.href = '../PHP/iritziak.php';
        </script>";
    }else{
        echo "<script>alert('Iruzkina gaizki gorde da.')</script>";
    }
}
?>