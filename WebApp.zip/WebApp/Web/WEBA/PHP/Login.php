<?php session_start();

$erabiltzaileak = simplexml_load_file("../xml/Erabiltzaileak.xml");

    $nan = $_POST['nan'];
    $pasahitza = $_POST['pasahitza'];

//administratzailearen datuak

    #Datuak irakurtzen joan
    foreach ($erabiltzaileak as $erabiltzailea){
        //XMLtik irakurri datuak
        $nanxml = $erabiltzailea->nan;
        $pasahitzaxml = $erabiltzailea->pasahitza;
        $tipo = $erabiltzailea->rola;
            if(($nan == $nanxml) && ($pasahitza == $pasahitzaxml)){
                if(($tipo=='bezero')){
                    $_SESSION['nan']=$nan;
                    echo'<script type="text/javascript">alert("Datuak zuzenak dira!"); window.location.href="../PHP/IkusiErreserbak.php"; </script>';
                }
                if(($tipo=='admin')){
                    echo'<script type="text/javascript">alert("Datuak zuzenak dira!"); window.location.href="../PHP/administratzailea.php"; </script>';
                }
            }
    }

        
    

    #erabiltzailea edo pasahitza zuzena ez den kasuan
    echo'<script type="text/javascript">alert("Erabiltzailea edo pasahitza ez dira zuzenak."); window.location.href="../html/Login.html"; </script>';

 ?>