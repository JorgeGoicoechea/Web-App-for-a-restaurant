<?php
if(isset($_POST["nan"])){
// Erreserba XML-a irakurri
$erreserbak = simplexml_load_file("../xml/Erreserbak.xml");
$nan = $_POST['nan'];
$mahaia = $_POST['mahaiak'];
$data = $_POST['data'];
$time = $_POST['time'];
$erreserba = $erreserbak->addChild('erreserba');
$erreserba->addChild('nan', $nan);
$erreserba->addChild('mahaia',$mahaia);
$erreserba->addChild('data',$data);
$erreserba->addChild('time',$time);

$erreserbak->asXML('../xml/Erreserbak.xml');


// Erabiltzaile XML-a irakurri

$erabiltzaileak = simplexml_load_file("../xml/Erabiltzaileak.xml");
$izena = $_POST['izena'];
$pasahitza = $_POST['pasahitza'];
$email = $_POST['email'];

$erabiltzailea = $erabiltzaileak->addChild('erabiltzailea');
$erabiltzailea->addChild('nan', $nan);
$erabiltzailea->addChild('izena',$izena);
$erabiltzailea->addChild('pasahitza',$pasahitza);
$erabiltzailea->addChild('email',$email);
$erabiltzailea->addChild('rola','bezero');

$erabiltzaileak->asXML('../xml/Erabiltzaileak.xml');

echo'<script type="text/javascript">
    alert("Erreserba ondo gorde da!");
    window.location.href="../html/Erreserbak.html";
    </script>';

}