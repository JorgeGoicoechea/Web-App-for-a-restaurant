//emaila balidatzen duen funtzioa, expresio erregularra erabiliz. Sartzen den emaila zuzena den egiaztatzeko. Iritziak orrian erabiltzeko
function EmailBalidazioa() {
    var email = document.getElementById("email").value;
    var reg1 = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!reg1.test(email)) {
        alert("email direkzioa ez da zuzena.");
        return false;

    } else {
        //alert("email direkzioa " + email + " zuzena da.");
        return true;
    }
}
//nan zenbakia balidatzen duen funtzioa, expresio erregularra erabiliz. Sartzen den nan zenbakia zuzena den egiaztatzeko. Erreserbak orrian erabiltzeko,email eta nan zenbakiaren balidazioa
function nanBalidazioa() {
    var nan = document.getElementById("nan").value;
    var email = document.getElementById("email").value;
    var reg1 = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    var reg2 = /^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$/;
    //datak lortu
    var gaur = new Date();
    var dataErreserba = document.getElementById("data").value;
    dataErreserba = new Date(dataErreserba);
    if (!reg1.test(email)) {
        alert("email ez da zuzena.");
        return false;
    } else if (!reg2.test(nan)) {
        alert("nan zenbakia ez da zuzena.");
        return false;

    } else if (gaur > dataErreserba) {//dataren balidazioa
        alert("Ezin da data hau aukeratu");
        return false;
    } else {
        return true;
    }
}

